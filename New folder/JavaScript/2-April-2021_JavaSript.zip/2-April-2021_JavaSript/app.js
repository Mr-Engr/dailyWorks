
///////////////////////////////////

// var statement1 = "My name is Zubair khan.";

// var h1 = prompt("Enter the statement nmae");
// var h2 = prompt("Enter the replace nmae");

// statement1 = statement1.replace(h1, h2);

// console.log(statement1);


///////////////////////////

// var statement1 = "My name is name Zubair name khan.";

// // var h1 = prompt("Enter the statement nmae");
// var h2 = prompt("Enter the replace nmae");

// statement1 = statement1.replace(/name/g, h2);

// console.log(statement1);





///////////////////////////////////////////////

//  var sentence = prompt ("Enter Any Sentence")
//  var  text1, part1=[];

//  for(var i=0; i<sentence.length;i++ )
//  {
//    text1= sentence.split(' ')

//  }

//  for(var j=0; j<text1.length;j++ )
//  {
// part1.push(text1[j][0].toUpperCase + text1[j].substr(1).toLowerCase())

//  }

//  console.log(part1.join(' '))


//  var statement = ("The quick brown fox jumps fox over the lazy dog.");

//  var lazyIndex = statement.indexOf("fox");
//   var lazylastIndex = statement.lastIndexOf("fox");

    
//   console.log(statement.slice(lazyIndex, lazylastIndex + 3));

//   var a =   console.log(statement.slice(lazyIndex, lazylastIndex + 3));

//////////////////////////////////////////////////////////////////////

// var statement = ("The quick brown fox jumps fox over fox the lazy dog.");




// for (var i=0; i < statement.length; i++ )
// {
//     var foxcase = statement.slice(i, i + 3);
    
//     if (foxcase === 'fox' )
//     {
//         statement  = statement.slice(0, i) + "cat" + statement.slice(i + 3);
       

//     }
// }
// console.log(statement);



////////////////

// var statement = ("The quick brown fox jumps fox over fox the lazy dog.");



//   var mat = prompt("Enter any text")
//   var replace = prompt("Enter the replace on same")


// for (var i=0; i < statement.length; i++ )
// {
//     var foxcase = statement.slice(i, i + mat.length);
    
//     if (foxcase === mat )
//     {
//         statement  = statement.slice(0, i) + replace + statement.slice(i + replace.length);
//         // allfoxindex.push(i);

//     }
// }

// console.log(statement);






////////////////////////////////////////

// var statement = ("The quick brown fox jumps fox over fox the lazy dog.");

//   var allfoxindex = [];

//   var mat = prompt("Enter any text")


// for (var i=0; i < statement.length; i++ )
// {
//     var foxcase = statement.slice(i, i+ mat.length);
    
//     if (foxcase === mat )
//     {
//         allfoxindex.push(i);

//     }
// }

// console.log('Condition matched.', allfoxindex);


//////////////////////////////////


// var statement = ("The quick brown fox jumps fox over the lazy dog");

// var foxIndex = statement.indexOf("fox");
// var foxlastIndex = statement.lastindexOf("fox");

//  console.log(statement.slice(foxIndex,foxlastIndex + 2));






// var name1 = prompt ("Enter Your Name");

// var upper = name1[0];
// var lower = name1.slice(1);


// console.log(upper.toUpperCase() + lower.toLowerCase());







// var tablename = prompt(" Enter the Table Name");
// var  times = prompt("# of iteration");

// for (var  i = 1; i<=times; i++ )
// {
 
//     console.log( tablename + "x" + i + "=" + (tablename*i));

// }


// var a = +prompt("Enter your Siblling Number");
// var array =   [];

// for (var i = 1; i < a; i++ )
// {

//      array1 = [prompt("Enter your sibling Names "  )];

//      array.push(array1);
     
     
// }
// console.log(array);
//  document.write(array);










// var cities = ["Asad","Ahsan","Arsalan","Arif","Saqib"];

// var favname =  cities.slice(2,4);

// console.log(favname);






// var cities = ["Asad","Ahsan","Arsalan","Arif","Saqib"];

// cities.splice(1,1,"saleem","jalil");

// console.log(cities);


//  var cities = ["Asad","Ahsan","Arsalan","Arif","Saqib"];
//  var t = prompt("ENter the name of deletion");
 
//  var i = cities.indexOf(t);

//  var k = prompt("Enter the name");
//  cities.splice(i,1,k )
//  console.log(cities);




// var ab = cities.indexOf("Arsalan");  

// console.log(ab);




// var cities = ["Asad","Ahsan","Arsalan","Arif","Saqib"];


// console.log(cities);
// cities.push("Saqib");
// console.log(cities);
// cities.unshift("Saleem");
// console.log(cities);
// cities.shift();
// console.log(cities);
// cities.shift();
// console.log(cities);
// cities.pop();
// console.log(cities);
// cities.pop();
// console.log(cities);


// var saqib = [];
// saqib[0] = "Ahmed";
// saqib[2] = "Dilawar";
// saqib[4] = "Sheikh";
// saqib[5] = "Shahzad";

// console.log(saqib);










// var num1 = +prompt("Enter the First Number");
// var num2 = +prompt("Enter the Second Number");

// if (num1 > num2){
//    console.log( "Number1 is greater than num2");
// }


// else if (num2 > num1){
//    console.log( "Number2 is greater than num1");
// }


// else if (num1 = num2){
//    console.log( "Number1 is equal to Number2");
// }

// else{
//    console.log("Both are different")

// }




// var a = +prompt("Enter the First Number");

// if( a > 0 ){

//    console.log( "Number1 is positive ");
// }

// else if(a < 0){

//    console.log( "Number1 is negative ");
// }

// else if(a == 0){

//    console.log( "Number1 is equal to zero");
// }


// else{

//    console.log( "Sometining went wrong");
// }




// var num = +prompt("Enter the Student Percentage");

// if (num >= 80 && num <= 100 ){
//    console.log( "Your Grade is A1 " + num );
// }


// else if (num >= 70 && num <= 79 ){
//    console.log("Your Grade is A " + num);
// }

// else if (num >= 60 && num <= 69){
//    console.log("Your Grade is B & Percentage  is " + num);
// }

// else if (num >= 50 && num <= 59){
//    console.log("Your Grade is C & Percentage  is " + num);
// }

// else if (num >=33  && num <= 49 ){
//     console.log("Your Grade is D & Percentage  is " + num);
//  }

// else {
// console.log("Sorry You are Failded " + num)

// }

// var username

// var myName = "zubair Khan";


// alert("Hello World");




// var children = '2', desig = 'assitant', loc = 'seaview', marital = 'single';


// alert('You will be a'+ desig, 'in USA' + 'and' + 'married to' + marital + 'with' + children + 'kids');     );


// Document.write("<h3>Yay! I can write HTML content through JavaSript</h3>");





// var a =10, b=20;
// var c = a+b;
// var d = a-b;
// var e = a*b;
// var f = a%b;

// console.log("The sum of " + a + "+" + b + "=" + c);
// console.log("The sub of " + a + "-" + b + "=" + d);
// console.log("The mul of " + a + "*" + b + "=" + e);
// console.log("The mod of " + a + "%" + b + "=" + f);



// var k = prompt("Enter the Value of ");


// console.log(k);


// ****************************************
/*
var n = +prompt("Enter The Table Number");

var time = 1;



console.log( n + "x" + time + "=" + n * time++ );
console.log( n + "x" + time + "=" + n * time++ );
console.log( n + "x" + time + "=" + n * time++ );
console.log( n + "x" + time + "=" + n * time++ );
console.log( n + "x" + time + "=" + n * time++ );
console.log( n + "x" + time + "=" + n * time++ );
console.log( n + "x" + time + "=" + n * time++);
console.log( n + "x" + time + "=" + n * time++ );
console.log( n + "x" + time + "=" + n * time++ );
console.log( n + "x" + time + "=" + n * time++ );


 ************************************ */



//  var qul = prompt("Enter the Qualification");
//  var mat  = ("matric", "mtric","metric","metrec");
// //  var mon = ('ramadan', 'muharram' );
 
//  if ( qul === mat)
//  {

//   console.log("You are enrolled in Matriculation" );

//  }
//  else {
    
//     console.log("Please complete your Matriculation"  );

//  }


// var num1 = +prompt("Enter the First Number");
// var oprand = prompt("Enter the operand");
// var num2 = +prompt("Enter the Second Number");
// var sum = (num1 + num2);
// var sub = (num1 - num2);

// if (oprand === "+"){
//    console.log( "the Sum of Number1 & Number2 is" + sum);
// }


// else if (oprand === "-") {
//    console.log( "the Sub of Number1 & Number2 is" + sub);
// }

// else {
//     console.log( "Wrong number");
//  }


// var num1 = prompt("Enter the First City Name");
// var num2 = prompt("Enter the Second City Name");
// var num3 = prompt("Enter the Third City Name");
// var num4 = prompt("Enter the Fourth City Name");
// var num5 = prompt("Enter the Fifth City Name");



// var  array = [];
//  array[0] = num1;
//  array[1] = num2;
//  array[2] = num3;
//  array[3] = num4;
//  array[4] = num5;

//  console.log(array);

//  var array1 = [prompt("Enter the First City Name"),prompt("Enter the First City Name"),prompt("Enter the First City Name"),prompt("Enter the First City Name"),prompt("Enter the First City Name"),prompt("Enter the First City Name"),prompt("Enter the First City Name"),]

// console.log(array1);






 